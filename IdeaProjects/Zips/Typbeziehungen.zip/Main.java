package Typbeziehungen;

import java.util.Random;

public class Main {
    public static void main(String[] args) {

        // [x] logik einer horde und herde in jeweils eine klasse.
        // [x] ziel soll sein horde.printName(); machen zu koennen
        // [x] ziel soll sein herde.printName(); machen zu koennen
        // [x] ziel soll sein Horde horde = new Horde(size);
        // [x] ziel soll sein herde.wirdGehuetet(horde);
        // [x] ziel soll sein horde.huetet(herde);
        // [] ziel soll sein schaf.verschwindet();

        Horde goDoggo = new Horde((int) Math.pow(10, 2));
        Herde goJeep = new Herde((int) Math.pow(10, 4));

        goDoggo.huetet(goJeep);
        goJeep.wirdGehuetet(goDoggo);


// 1_000_000_000 = 100 * 10_000_000

//        String name = "bella";
//        Hund frodo = new Hund(5);
//        Hund frido = new Schaefer(5);
//        Schaefer schaefo = new Schaefer(5);
//        Schaf schuf = new Schaf(name);
//
//        frodo.hueten(schuf);
//        frido.hueten(schuf);
//        schaefo.hueten(schuf);

//        frido.hueten(new Schaf());
    }
}

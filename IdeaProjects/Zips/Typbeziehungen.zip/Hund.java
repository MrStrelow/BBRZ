package Typbeziehungen;

public class Hund {

    private Integer alter;
    private String name;

    public Hund(Integer alter, String name) {
        this.alter = alter;
        this.name = name;
    }

    public void hueten(Schaf schaf) {
        System.out.println("Ich bin ein Hund, mit Namen " + name + " und bin " + alter + " alt und huete heute das Schaf " + schaf);
    }

    public String toString() {
        return getName();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getAlter() {
        return alter;
    }

    public void setAlter(Integer alter) {
        this.alter = alter;
    }
}

package Typbeziehungen;

import java.util.Random;

public class Horde {
    private Integer size;
    private Hund[] hunde;

    public Horde(Integer size) {
        this.size = size;
        this.hunde = new Hund[size];
        Random random = new Random();

        for (int i = 0; i < size; i++) {
            Integer alter = random.nextInt(1, 8);

            char zufallsName = (char) random.nextInt(97, 97 + 26);
            String name = Character.toString(zufallsName);

            hunde[i] = new Hund(alter, name);
        }
    }

    public void huetet(Herde schafe) {
//        for (int i_hund = 0; i_hund < size; i_hund++) {
//            for (int i_schaf = 0; i_schaf < schafe.getSize(); i_schaf++) {
        for (Hund hund : hunde) {
            for (Schaf schaf : schafe.getSchafe()) {
                hund.hueten(schaf);
            }
        }
    }

    public String printName() {
        String ausgabe = "";

//        for (int i = 0; i < size; i++) {
//            ausgabe += hund[i].getName() + "\n";
//        }
        for (Hund hund : hunde) {
            ausgabe += hund.getName() + "\n";
        }

        return ausgabe;
    }

    public Integer getSize() {
        return size;
    }

    public void setSize(Integer size) {
        this.size = size;
    }

    public Hund[] getHunde() {
        return hunde;
    }

    public void setHunde(Hund[] hunde) {
        this.hunde = hunde;
    }
}

package Klassen3;

public class Material {
}

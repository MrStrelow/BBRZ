package com.example.logindemo;

import javafx.fxml.FXML;

public class RegisterController {

    @FXML
    protected void createUser() {

    }

    @FXML
    protected void generatePasswordForUser() {

    }
}

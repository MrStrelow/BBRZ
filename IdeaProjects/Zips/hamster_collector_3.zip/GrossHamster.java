package hemstr;

public class GrossHamster {
    // Attribute
    // hat-Relationen
    // Konstruktor
    // methoden
    // getter-setter
}

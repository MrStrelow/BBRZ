package hemstr;

public enum Richtung {
    links,
    rechts,
    unten,
    oben
}

package Typbeziehungen;

import java.util.ArrayList;
import java.util.Random;

public class Main {
    public static void main(String[] args) throws Exception {

        // [x] ein Hund ist zu alt
        // [] ein huetet zu viel exception

        // []



        try {

            Hund dog = new Hund(10, "welp");

        } catch (ZuAltException alt) {

            System.out.println("Oida, " + alt.getMessage());
            // schreibe in seniorenschutz datenbank
            System.out.println("meldung an seniorenschutz abgesendet.");

        } catch (ZuJungException jung) {

            System.out.println("Deppata, " + jung.getMessage());
            // schreibe in seniorenschutz datenbank
            System.out.println("meldung an jugendschutz abgesendet.");

        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            System.out.println("das im finally block wird gemacht egal ob ein fehler passiert oder nicht.");
        }

        System.out.println("HIER BEGINNT DIE ERSTELLUNG DER HORDE!");

        Horde goDoggo = new Horde((int) Math.pow(10, 2));
        Horde goDuggo = new Horde((int) Math.pow(10, 2));

        // implments comparable
        if( goDoggo.compareTo(goDuggo) > 0 ) {
            System.out.println("goDoggo ist mächtiger.");

        } else if ( goDoggo.compareTo(goDuggo) < 0 ) {
            System.out.println("goDoggo ist schwächer.");

        } else {
            System.out.println("horden sind gleich mächtig.");
        }

        System.out.println(goDoggo.isEmpty());

        Hund frido = new Hund(5,"frido");
        Hund frodo = new Hund(5,"frodo");
        System.out.println(frodo.equals(frido));

        System.out.println("#####################");

        System.out.println(goDoggo.size());
        Hund finder = new Hund(5, "finder");
        goDoggo.add(finder);
        System.out.println(goDoggo.size());
        goDoggo.remove(finder);
        System.out.println(goDoggo.size());


//        Hund sad = null;
//        System.out.println(sad);
//
//        ArrayList<Hund> asdf = new ArrayList<>();
//        System.out.println(asdf);
//        asdf.add(null);
//        System.out.println(asdf);
//        System.out.println(asdf.isEmpty());


//        // implements Collection
//        goDoggo.add();
//        goDoggo.remove(10);
//        goDoggo.remove(dog);
//
//        for(Hund dog : goDoggo) {
//
//        }

//        Hund frido = new Hund(5,"frido");
//        Hund frodo = new Hund(5,"frido");
//        System.out.println(frido.equals(frodo));
//
//        String sfrido = new String("frido");
//        String sfrodo = new String("frido");
//        System.out.println(sfrido.equals(sfrodo));
//        System.out.println(sfrido == sfrodo);
//        sfrido = sfrodo;
//        System.out.println(sfrido == sfrodo);

        Herde goJeep = new Herde((int) Math.pow(10, 4));

//        goDoggo.huetet(goJeep);
//        goJeep.wirdGehuetet(goDoggo);
    }
}

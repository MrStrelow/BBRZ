package Typbeziehungen;

public class ZuAltException extends Exception {
    public ZuAltException() {
        super("This Dog is too old");
    }
}

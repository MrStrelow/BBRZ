package KlassenZahlen;

public interface Transformierbar {
    Transformierbar transformieren(Transformierbar x);
}

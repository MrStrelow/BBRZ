package Klassen2;

public class Mensch {
    // Attribute sind nomen

    private Double health;
    private Integer age;

    //Methoden sind verben
    public void beingDepressed() {
        System.out.println(":(");
        health /= 2; // ist das gleiche health = health/2
    }

}

//    public void addNumbers(Integer a, Integer b) {
//        System.out.println(a+b);
//    }
//
//    public Integer addReturnNumbers(Integer a, Integer b) {
//        return a+b;
//    }

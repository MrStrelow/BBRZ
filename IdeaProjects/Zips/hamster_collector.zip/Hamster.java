package hemstr;

public class Hamster {
    // Attribute
    // hat-Relationen
    // Konstruktor
    // methoden
    // getter-setter
}

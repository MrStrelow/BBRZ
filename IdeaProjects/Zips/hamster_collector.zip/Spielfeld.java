package hemstr;

import java.util.Random;

public class Spielfeld {
    // Attribute
    private String[][] spielfeld;
    private String bodenSymbol = "_";
    private String samenSymbol = "o";
    private String hamsterSymbol = "x";
    private int groesse = 5;

    // hat-Relationen
    private Samen[] samen;

    // Konstruktor

    public Spielfeld() {
        // hier ist die Logik der Darstellung drinnen
        spielfeld = new String[groesse][groesse];

        // spielfeld mit leerzeichen befüllen
        for (int i = 0; i < groesse; i++) {
            for (int j = 0; j < groesse; j++) {
                spielfeld[i][j] = bodenSymbol;
            }
        }

        // hier ist Logik ohne spezielle Darstellung vorhanden.
        samen = new Samen[groesse*groesse-1];

        Random random = new Random();
        Integer anzahlSamen = random.nextInt(1, groesse*groesse-1);

        for (int i = 0; i < anzahlSamen; i++) {
            samen[i] = new Samen(this);
        }
    }


    // methoden
    public void weiseSamenZu(Samen samen) {
        Random random = new Random();
        int x = random.nextInt(groesse);
        int y = random.nextInt(groesse);

        if(spielfeld[y][x].equals(bodenSymbol)){
            samen.setX(x);
            samen.setY(y);

            spielfeld[y][x] = "o";
        } else {

            // rekursion!!! wenns spielfeld bereits voll ist, probiers nocheinmal.
            weiseSamenZu(samen);

        }

    }


    public void printSpielfeld() {
        for (int i = 0; i < groesse; i++) {
            for (int j = 0; j < groesse; j++) {
                System.out.print(spielfeld[i][j]);
            }
            System.out.println();
        }
    }


    // getter-setter
}

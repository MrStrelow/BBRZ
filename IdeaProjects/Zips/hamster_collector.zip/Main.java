package hemstr;

public class Main {
    public static void main(String[] args) {
        Spielfeld meinFeld = new Spielfeld();
        meinFeld.printSpielfeld();
    }
}

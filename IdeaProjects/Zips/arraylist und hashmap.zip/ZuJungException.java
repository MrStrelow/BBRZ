package Typbeziehungen;

public class ZuJungException extends Exception {
    public ZuJungException() {
        super("This Dog is too young");
    }
}

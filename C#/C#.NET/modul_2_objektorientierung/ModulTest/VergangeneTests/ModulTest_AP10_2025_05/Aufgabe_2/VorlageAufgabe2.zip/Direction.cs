﻿namespace Hamster;
public enum Direction
{
    LEFT,
    RIGHT,
    DOWN,
    UP
}

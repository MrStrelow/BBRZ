﻿using Fahrradverleih.DTOs;
using Fahrradverleih.Entities;
using Fahrradverleih.Exceptions;
using Fahrradverleih.Repositories;
using Serilog;
using System;
using System.Threading.Tasks;

namespace Fahrradverleih.Services
{
    public interface IReservierungsService
    {
        Task<Reservierung> ErstelleReservierungAsync(ReservierungsWunschDto wunsch);
    }

    public class ReservierungsService : IReservierungsService
    
        // TODO: Erstelle die benötigten Felder und Eigenschaften.

        // TODO: Implementiere den Konstruktor.
        public ReservierungsService()
        {
            throw new NotImplementedException();
        }

        public async Task<Reservierung> ErstelleReservierungAsync(ReservierungsWunschDto wunsch)
        {
            // TODO: Implementiere die Erstellung einer Reservierung:
            // * rufe dazu _kundeRepository.GetByIdAsync, sowie _fahrradRepository.GetByIdAsync auf.
            

            Log.Information("Erstelle Reservierung für Kunde {KundenName} für Fahrrad {FahrradModell} am {ReservierungsDatum}",
                kunde.Name, fahrrad.Modell, wunsch.ReservierungsDatum);

            // * Erstelle ein Objekt reservierung, welches Kunde, Fahrrad und das ReservierungsDatum (kommt aus dem Parameter wunsch)
            // * Füge diese Reservierung dem _reservierungRepository mit AddAsync hinzu.
            Log.Information("Reservierung erfolgreich erstellt.");
            return reservierung;
        }
    }
}
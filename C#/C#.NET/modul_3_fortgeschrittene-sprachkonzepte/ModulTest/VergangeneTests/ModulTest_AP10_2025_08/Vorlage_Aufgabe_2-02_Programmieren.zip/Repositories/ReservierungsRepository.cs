﻿using Fahrradverleih.Entities;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace Fahrradverleih.Repositories
{
    public interface IReservierungsRepository
    {
        Task<IEnumerable<Reservierung>> GetAllAsync();
        Task AddAsync(Reservierung reservierung);
    }

    public class ReservierungsRepository : IReservierungsRepository
    {
        // TODO: Erstelle die benötigten Felder und Eigenschaften.

        // TODO: Implementiere den Konstruktor.
        public ReservierungsRepository()
        {
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<Reservierung>> GetAllAsync()
        {
            // TODO: Implementiere:
            // * ein Lock für File während dem Lesen, welches gleichzeige Zugriffe verhindert.
            // * Versuche (Try) die Methode ReadFromFileAsync aufzurufen und gib anschließen, egal was passiert (finally), den Lock wieder frei.
            throw new NotImplementedException();
        }

        public async Task AddAsync(Reservierung reservierung)
        {
            // TODO: Implementiere:
            // * ein Lock für File während dem Schreiben, welches gleichzeige Zugriffe verhindert.
            // * Versuche (Try) die Methode
            //      * ReadFromFileAsync aufzurufen, speicher das Ergebnis und fürge den Parameter reservierung hinzu,
            //      * danach rufe WriteToFileAsync auf.
            // * anschließendd gib, egal was passiert (finally), den Lock wieder frei,
            throw new NotImplementedException();
        }

        private async Task<List<Reservierung>> ReadFromFileAsync()
        {
            // TODO: Implementiere:
            // * Die Deserialisierung der Liste von Reservierungen, welche aus einem JSON stammt.
            // * Verwende dazu File.ReadAllTextAsync und JsonSerializer.Deserialize.
            throw new NotImplementedException();
        }

        private async Task WriteToFileAsync(IEnumerable<Reservierung> reservierungen)
        {
            // TODO: Implementiere:
            // * Die Serialisierung der Liste von Reservierungen als JSON, welche als Parameter übergeben wird.
            // * Verwende dazu JsonSerializer.Serialize und File.WriteAllTextAsync.
            throw new NotImplementedException();
        }
    }
}
﻿using System;
using System.Threading.Tasks;
using Serilog;
using Ticketverkauf.DTOs;
using Ticketverkauf.Entities;
using Ticketverkauf.Repositories;

namespace Ticketverkauf.Services
{
    public interface IZugService
    {
        Task<Ticket> KaufeZugTicketAsync(TicketKaufWunschDto wunsch);
    }

    public class ZugService : IZugService
    {
        // TODO: Erstelle die benötigten Felder und Eigenschaften.

        // TODO: Implementiere den Konstruktor.
        public ZugService()
        {
           
        }

        public async Task<Ticket> KaufeZugTicketAsync(TicketKaufWunschDto wunsch)
        {
            // TODO: Implementiere die Erstellung eines Tickets:
            // * rufe dazu _kundeRepository.GetByIdAsync, sowie _zugRepository.GetByIdAsync auf.
            // * Erstelle ein Objekt neuesTicket, welches Kaeufer, GekauftesVerkehrsmittel und den Preis (kommt aus dem Parameter wunsch) beinhaltet.

            Log.Information("Zugticket für Zug {ZugNummer} ({Start} -> {Ziel}) an {KundenName} für {Preis}€ verkauft.",
                zug.ZugNummer, zug.StartBahnhof, zug.ZielBahnhof, kunde.Name, zug.TicketPreis);

            // * Füge das Ticket dem _ticketRepository mit AddAsync hinzu.
        }
    }
}
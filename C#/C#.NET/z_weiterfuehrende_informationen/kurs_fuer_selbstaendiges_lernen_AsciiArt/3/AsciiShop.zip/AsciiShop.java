import java.util.Scanner;


public class AsciiShop {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		boolean start = true;
		int refLength = 0;
		String[] image = {};
		boolean read = true;
		boolean output = false;
		int readLine = 0;
		int x;
		int y;
		char c;
		
		if(sc.next().equals("read")){
			
			readLine = sc.nextInt();				
			
			for(int i = 0; i < readLine; i++){
				
				String line=sc.next();
					
				if(start){ 		// abfrage ob die referenzzeile zu setzen ist 
					start=false;
					refLength = line.length();	// setzen der referenzzeile -> erste eingabe
					image = new String[readLine];
				}
				else if(line.length() != refLength){
					read = false;
					System.out.println("INPUT MISMATCH");										
					break;										//fehler liegt vor -> verlasse schleife sofort
				}				
				
				image[i] = line;
			}
			
			while(sc.hasNext() && read){	// read um zu vermeiden dass inputmissmatch 2 mal ausgegeben wird wenn 27 zeilen eingelesen werden sollten aber nur 5 eingegeben wurden
				String next = sc.next();
				output = false;				// um ausgabe zu vermeiden wenn einmal ein richtiger befehl eingegeben wurde jedoch der n�chste falsch ist
					
				if(next.equals("fill")){
					if(sc.hasNextInt()){	// um  fehler  abzufangen -> fill e 2 #
						x = sc.nextInt();
						
						if(sc.hasNextInt()){	// um folgefehler abzufangen -> fill 1 e #
							y = sc.nextInt();	
							c = sc.next().toCharArray()[0];		// ben�tigt keine �berpr�fung -> fill 1 0 asdfasdfasdf -> es wird 'a' als char genommen
						}
						else{
							System.out.println("INPUT MISMATCH");
							break;
						}
					}
					else{
						System.out.println("INPUT MISMATCH");
						break;
					}
					
					if(image.length > y && y >= 0 && image[y].length() > x && x >= 0){
						fill(image, x, y, c);
					}
					else{
						System.out.println("OPERATION FAILED");
						break;
					}	
				}
				else{
					System.out.println("INPUT MISMATCH");
					break;
				}
				
				output = true;	 // wird auf true gesetz -> wenn das programm hier ist muss die eingabe ture sein
			}
		}
		else{
			System.out.println("INPUT MISMATCH");
		}
				
		if(output){
			for(String a : image){
				System.out.println(a);
			}
			
			System.out.println(image[0].length()+" "+image.length);	
		}
		
		sc.close();
	}	
	public static void fill(String[] image, int x, int y, char c){ 
		
		char old = image[y].charAt(x);
		image[y] = image[y].substring(0, x) + c + image[y].substring(x+1); 
		
		if(x < image[y].length() - 1){
			if(image[y].charAt(x + 1) == old){
				fill(image, x + 1, y, c); // rechts -> x++	
			}
		}			
		if(y < image.length - 1){
			if(image[y + 1].charAt(x) == old){
				fill(image, x, y + 1 , c); // unten -> y++	
			}
		}			
		if(x > 0){
			if(image[y].charAt(x - 1) == old){
				fill(image, x - 1, y, c); // links -> x--	
			}
		}			
		if(y > 0){
			if(image[y - 1].charAt(x) == old){
				fill(image, x, y - 1, c); // oben -> y--	
			}
		}
	}
}
import java.util.ArrayList;
import java.util.Locale;
import java.util.Scanner;

public class BarPlot {
	
	public static void main(String[] args) {
		
		Locale.setDefault(new Locale("en","US"));	 // damit . als komma geht
		Scanner sc = new Scanner(System.in);		
		ArrayList<String> list = new ArrayList<String>();  // f�r speicherung der barplots um ausgabe nach kompletter eingabe zu erzeugen
		
		while(sc.hasNext()){
			
			String output;
			String label = sc.next();
			int n;
			double nd;
			
			if(sc.hasNextInt()){			// n�chster teil des eingabe eine ganzzahl?
				n = sc.nextInt();
				output = drawBar(drawLabel(label, 8), n);
			}
			else if(sc.hasNextDouble()){	// n�chster teil des eingabe eine kommazahl?
				nd = sc.nextDouble();
				output = drawBar(drawLabel(label, 8), nd);
			}
			else{
				output = "INPUT ERROR";
			}
			
			if(output.equals("INPUT ERROR")){
				list.add(output);
				break;
			}
			else{
				list.add(output);
			}
		}
		
		for(String a : list){
			System.out.println(a);
		}
		
		sc.close();
	}
	
	static String repeat(char c, int n){
		char[] ret = new char[n];	// char array f�r ges anzahl der zeichen
		
		for(int i = 0; i < n; i++){
			ret[i] = c;
		}
		return String.copyValueOf(ret); // r�ckrabe als string
	}
	
	static String drawLabel(String label, int n){
		String ret=label;

		if(label.length() >= n){		//n ist max platz f�r label
			ret = label.substring(0, n);	// wenn gr��er wird es abgeschnitten
		}else{
			
			ret += repeat(' ',n - label.length()); // wenn kleiner ' ' hinzugef�gt
		}
		
		return ret;
	}
	
	static String drawBar(String label, int value){
		
		String tempPlot = repeat('#', value);
		int tempPlotLength;
		
		if(tempPlot.length() > 30){
			return "INPUT ERROR";
		}
		
		tempPlotLength = 30 - tempPlot.length();
		tempPlot += repeat(' ', tempPlotLength);

		return label+"|"+tempPlot+"|";		
	}
	
	static String drawBar(String label, double value){

		/*if(value > Integer.MAX_VALUE){
			return "INPUT ERROR";
		}*/
		
		int valueN = (int) Math.round(30*value);
		String tempPlot = repeat('#', valueN);
		int tempPlotLength;
		
		if(tempPlot.length() > 30){
			return "INPUT ERROR";
		}
		
		tempPlotLength = 30 - tempPlot.length();
		tempPlot += repeat(' ', tempPlotLength);

		return label+"|"+tempPlot+"|";	
	}
}

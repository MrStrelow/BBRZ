### Aufbau
Die Struktur der Vorlage ist **unabhängig vom Editor beizubehalten**. Diese ist:
- Eine ``Projektmappe``(Solution) für die ``Prüfung``
- Pro ``Aufgabe`` in der ``Prüfung`` ein ``Projekt``
- Pro ``Projekt`` eine eigene ``Dateien`` für ``01_Programmverständnis``, ``02_Programmieren`` und ``03_Theorie``. Falls die ``Aufgabe`` z.B. nur ``02_Programmieren`` und ``03_Theorie`` in der Angabe besitzt, müssen nur diese beiden ``Dateien`` angelegt werden.

### Offnen der Vorlage
Es existieren mehrere Möglichkeiten um die ``Projektmappe`` in ``Visual Studio`` zu öffnen. Wähle in allen Varianten eine Datei aus, welche die Endung *".sln"* hat. (Falls die Endungen nicht sichtbar sind, ist es in der Vorlage die Datei mit Namen "PruefungMeinName" im Ordner "PruefungMeinName" und einem violetten Visual Studio icon.)

* Öffne ``Visual Studio`` und wähle ``Projektmappe öffnen`` (Open a Project or Solution) auf der rechten seite.
![alt text](figures/variante_1.png)

* Falls ``Visual Studio`` schon geöffnet ist, verwende folgendes. 
![alt text](figures/variante_2.png)

* Alternativ kann bevor ``Visual Studio`` geöffnet wurde mit einem Doppel-Klick die Datei mit der Solution-Endung *".sln"* geöffnet werden. Das funktioniert nur wenn in Windows die *".sln"* Dateien mit Visual Studion als Standardprogramm verknüpft ist.  
![alt text](figures/variante_3.png)

### Abgabe
Die Abgabe erfolgt als ``ZIP``-Datei. In dieser füge die ``Projektmappe``(Solution) mit all dessen ``Projekten`` ein.
﻿namespace Fahrradverleih.Entities;

public class Kunde
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
}
﻿using Fahrradverleih.DTOs;
using Fahrradverleih.Entities;
using Fahrradverleih.Exceptions;
using Fahrradverleih.Repositories;
using Serilog;
using System;
using System.Threading.Tasks;

namespace Fahrradverleih.Services;

public interface IReservierungService
{
    Task<Reservierung> ErstelleReservierungAsync(ReservierungsWunschDto wunsch);
}

public class ReservierungService : IReservierungService
{
    // TODO: Felder von Repositories
    // TODO: Konstruktor welcher Repositories als Parameter übergeben bekommt und mit Felder verlinkt.

    public async Task<Reservierung> ErstelleReservierungAsync(ReservierungsWunschDto wunsch)
    {
        // TODO: Logik.
        // Verwende User und Fahrrad aus wunsch,
        // Lade User und Fahrrad mithilfe des Repositories,
        // Erstelle reservierung und speichere diese mit dem ReservierungsRepository.
    }
}
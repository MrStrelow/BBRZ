﻿using Fahrradverleih.Entities;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace Fahrradverleih.Repositories
{
    public interface IReservierungsRepository
    {
        Task<IEnumerable<Reservierung>> GetAllAsync();
        Task AddAsync(Reservierung reservierung);
    }

    public class ReservierungRepository : IReservierungsRepository
    {
        // TODO: siehe andere Repositories.

        public ReservierungRepository()
        {
            // TODO: siehe andere Repositories.
        }

        public async Task<IEnumerable<Reservierung>> GetAllAsync()
        {
            // TODO: lade alle Reservierungen async.
        }

        public async Task AddAsync(Reservierung reservierung)
        {
            // TODO: Füge eine Reservierungen async hinzu.
        }

        private async Task<List<Reservierung>> ReadFromFileAsync()
        {
            // TODO: hilfsmethode, wird von GetAllAsync verwendet.
        }

        private async Task WriteToFileAsync(IEnumerable<Reservierung> reservierungen)
        {
            // TODO: hilfsmethode, wird von AddAsync verwendet.
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Serilog;
using Ticketverkauf.DTOs;
using Ticketverkauf.Entities;
using Ticketverkauf.Repositories;
using Ticketverkauf.Services;

Log.Logger = new LoggerConfiguration()
    .MinimumLevel.Debug()
    .WriteTo.Console()
    .CreateLogger();

Log.Information("--- Ticketverkaufs-System startet ---");

var kundenRepo = new KundenRepository();
var busRepo = new BusRepository();
var zugRepo = new ZugRepository(); 
var ticketRepo = new TicketRepository();

await kundenRepo.SaveAllAsync(new List<Kunde>
{
    new() { Id = 1, Name = "Anna Schmidt" },
    new() { Id = 2, Name = "Ben Meier" },
    new() { Id = 3, Name = "Clara Huber" }
});

await busRepo.SaveAllAsync(new List<Bus>
{
    new() { Id = 101, Linie = "48A", TicketPreis = 2.40m },
    new() { Id = 102, Linie = "13A", TicketPreis = 2.40m }
});

await zugRepo.SaveAllAsync(new List<Zug>
{
    new() { Id = 201, ZugNummer = "RJX 765", StartBahnhof = "Wien Hbf", ZielBahnhof = "Salzburg Hbf", TicketPreis = 59.90m },
    new() { Id = 202, ZugNummer = "ICE 28", StartBahnhof = "Wien Hbf", ZielBahnhof = "München Hbf", TicketPreis = 89.90m }
});

var ticketService = new TicketService(kundenRepo, busRepo, zugRepo, ticketRepo);
var analyseService = new AnalyseService(ticketRepo);


Log.Information("--- Ticketverkäufe werden simuliert ---");

var kaufWunsch1 = new TicketKaufWunschDto { KundenId = 1, VerkehrsmittelId = 101, Typ = VerkehrsmittelTyp.Bus };
Task<Ticket> kauf1 = ticketService.KaufeTicketAsync(kaufWunsch1);

var kaufWunsch2 = new TicketKaufWunschDto { KundenId = 2, VerkehrsmittelId = 102, Typ = VerkehrsmittelTyp.Bus };
Task<Ticket> kauf2 = ticketService.KaufeTicketAsync(kaufWunsch2);

var kaufWunsch3 = new TicketKaufWunschDto { KundenId = 1, VerkehrsmittelId = 102, Typ = VerkehrsmittelTyp.Bus };
Task<Ticket> kauf3 = ticketService.KaufeTicketAsync(kaufWunsch3);

var kaufWunsch4 = new TicketKaufWunschDto { KundenId = 3, VerkehrsmittelId = 201, Typ = VerkehrsmittelTyp.Zug };
Task<Ticket> kauf4 = ticketService.KaufeTicketAsync(kaufWunsch4);

var kaeufe = new List<Task<Ticket>> { kauf1, kauf2, kauf3, kauf4 };

await Task.WhenAll(kaeufe);

Log.Information("--- Analyse wird durchgeführt ---");
var analyseErgebnis = await analyseService.FindeKundenMitDenMeistenTicketsAsync();

if (analyseErgebnis.KundeMitDenMeistenTicketsId.HasValue)
{
    Log.Information("Der Kunde mit den meisten Tickets ist: {KundenName} (ID: {KundenId})",
        analyseErgebnis.KundeMitDenMeistenTicketsName, analyseErgebnis.KundeMitDenMeistenTicketsId);
}
else
{
    Log.Information("Es konnte kein Kunde mit den meisten Tickets ermittelt werden.");
}

Log.Information("--- System wird beendet ---");
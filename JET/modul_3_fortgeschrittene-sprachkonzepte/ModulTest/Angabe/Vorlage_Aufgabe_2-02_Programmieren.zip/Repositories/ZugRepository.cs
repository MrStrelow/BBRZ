﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Ticketverkauf.Entities;

namespace Ticketverkauf.Repositories
{
    public interface IZugRepository
    {
        Task<IEnumerable<Zug>> GetAllAsync();
        Task<Zug?> GetByIdAsync(int id);
        Task SaveAllAsync(IEnumerable<Zug> zuege);
    }

    public class ZugRepository : IZugRepository
    {
        // TODO: Erstelle die benötigten Felder und Eigenschaften.
        
        // TODO: Implementiere den Konstruktor.
        public ZugRepository()
        {
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<Zug>> GetAllAsync()
        {
            // TODO: Implementiere:
            // * ein Lock für File während dem Lesen, welches gleichzeige Zugriffe verhindert.
            // * Versuche (Try) die Methode ReadFromFileAsync aufzurufen und gib anschließen, egal was passiert (finally), den Lock wieder frei.
            throw new NotImplementedException();
        }

        public async Task<Zug?> GetByIdAsync(int id)
        {
            // TODO: Implementiere:
            // * rufe die Methode GetAllAsync auf und filtere anshcließend nach der ID. 
            throw new NotImplementedException();
        }

        public async Task SaveAllAsync(IEnumerable<Zug> zuege)
        {
            // TODO: Implementiere:
            // * ein Lock für File während dem Schreiben, welches gleichzeige Zugriffe verhindert.
            // * Versuche (Try) die Methode WriteToFileAsync aufzurufen.
            // * anschließend gib, egal was passiert (finally), den Lock wieder frei.
            throw new NotImplementedException();
        }

        private async Task<List<Zug>> ReadFromFileAsync()
        {
            // TODO: Implementiere:
            // * Die Deserialisierung der Liste von Zügen, welche aus einem JSON stammt.
            // * Verwende dazu File.ReadAllTextAsync und JsonSerializer.Deserialize.
            throw new NotImplementedException();    
        }

        private async Task WriteToFileAsync(IEnumerable<Zug> zuege)
        {
            // TODO: Implementiere:
            // * Die Serialisierung der Liste von Reservierungen als JSON, welche als Parameter übergeben wird.
            // * Verwende dazu JsonSerializer.Serialize und File.WriteAllTextAsync.
            throw new NotImplementedException();
        }
    }
}
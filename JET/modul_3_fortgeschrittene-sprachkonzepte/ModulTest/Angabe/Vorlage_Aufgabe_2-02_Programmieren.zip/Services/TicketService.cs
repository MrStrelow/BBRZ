﻿using System;
using System.Threading.Tasks;
using Serilog;
using Ticketverkauf.DTOs;
using Ticketverkauf.Entities;
using Ticketverkauf.Repositories;

namespace Ticketverkauf.Services
{
    public interface ITicketService
    {
        Task<Ticket> KaufeTicketAsync(TicketKaufWunschDto wunsch);
    }

    public class TicketService : ITicketService
    {
        // TODO: Erstelle die benötigten Felder und Eigenschaften.
        private readonly IKundenRepository _kundenRepository;
        private readonly IBusRepository _busRepository;
        private readonly IZugRepository _zugRepository;
        private readonly ITicketRepository _ticketRepository;

        public TicketService(IKundenRepository kundenRepo, IBusRepository busRepo, IZugRepository zugRepo, ITicketRepository ticketRepo)
        {
            _kundenRepository = kundenRepo;
            _busRepository = busRepo;
            _zugRepository = zugRepo;
            _ticketRepository = ticketRepo;
        }

        public async Task<Ticket> KaufeTicketAsync(TicketKaufWunschDto wunsch)
        {
            var kunde = await _kundenRepository.GetByIdAsync(wunsch.KundenId)
                        ?? throw new InvalidOperationException($"Kunde mit ID {wunsch.KundenId} nicht gefunden.");

            ITransportmittel verkehrsmittel;

            if (wunsch.Typ == VerkehrsmittelTyp.Bus)
            {
                verkehrsmittel = await _busRepository.GetByIdAsync(wunsch.VerkehrsmittelId)
                                 ?? throw new InvalidOperationException($"Bus mit ID {wunsch.VerkehrsmittelId} nicht gefunden.");
                Log.Information("Busticket wird für {KundenName} vorbereitet.", kunde.Name);
            }
            else if (wunsch.Typ == VerkehrsmittelTyp.Zug)
            {
                verkehrsmittel = await _zugRepository.GetByIdAsync(wunsch.VerkehrsmittelId)
                                 ?? throw new InvalidOperationException($"Zug mit ID {wunsch.VerkehrsmittelId} nicht gefunden.");
                Log.Information("Zugticket wird für {KundenName} vorbereitet.", kunde.Name);
            }
            else
            {
                throw new NotSupportedException("Dieser Verkehrsmitteltyp wird nicht unterstützt.");
            }

            var neuesTicket = new Ticket
            {
                Kaeufer = kunde,
                GekauftesVerkehrsmittel = verkehrsmittel,
                // Direkter Zugriff auf die Eigenschaft der Basisklasse
                Preis = verkehrsmittel.TicketPreis
            };

            Log.Information("Ticket für {KundenName} für {Preis}€ erfolgreich erstellt.", kunde.Name, neuesTicket.Preis);

            await _ticketRepository.AddAsync(neuesTicket);
            return neuesTicket;
        }
    }
}

public class BinaryOperation implements Operation{
	private Character threshold;

	public BinaryOperation(char threshold){
		this.threshold=threshold;
	}
	public AsciiImage execute(AsciiImage img) throws OperationException {
		AsciiImage ret = new AsciiImage(img);
		
		if(!ret.getCharSet().contains(threshold.toString())){
			throw new OperationException();
		}
		
		for(int i=0; i<ret.getImage().length; i++){
			for(int j=0; j<ret.getImage()[i].length; j++){
				if(isBrighter(threshold, ret.getPixel(new AsciiPoint(j,i)), ret.getCharSet())){
					ret.setPixel(new AsciiPoint(j, i), ret.getCharSet().charAt(ret.getCharSet().length()-1));
				}
				else{
					ret.setPixel(new AsciiPoint(j, i), ret.getCharSet().charAt(0));
				}
			}
		}
		
		return ret;
	}
	
	private boolean isBrighter(char threshold, char c, String charSet){
		boolean ret=true;
		
		if(charSet.indexOf(c) < charSet.indexOf(threshold)){
			ret=false;
		}
		
		return ret;
	}

}

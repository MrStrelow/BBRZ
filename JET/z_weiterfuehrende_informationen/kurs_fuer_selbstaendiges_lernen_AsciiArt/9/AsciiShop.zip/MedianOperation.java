import java.util.ArrayList;
import java.util.Collections;


public class MedianOperation extends FilterOperation{
	
	@Override
	public char filter(char[][] temp, String charSet) {
		char ret;
		ArrayList<Character> medianList = new ArrayList<Character>();
		
		for(int e=0; e<temp.length; e++){
			for(int r=0; r<temp[e].length; r++){
				medianList.add(temp[e][r]);	
			}
		}
		
		ret=sort(medianList, charSet).get(medianList.size()/2);
		return ret;
	}
}

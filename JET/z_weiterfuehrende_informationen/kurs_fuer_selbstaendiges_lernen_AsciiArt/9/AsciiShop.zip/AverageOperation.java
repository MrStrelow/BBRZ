import java.util.ArrayList;


public class AverageOperation extends FilterOperation{

	@Override
	public char filter(char[][] temp, String charSet) {
		double sum=0;
		int anz=0;
		ArrayList<Character> averageList = new ArrayList<Character>();
		
		for(int e=0; e<temp.length; e++){
			for(int r=0; r<temp[e].length; r++){
				sum+=charSet.indexOf(temp[e][r]);
				anz++;
			}
		}
		return charSet.charAt((int)Math.round(sum/anz));
	}

}

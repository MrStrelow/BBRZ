import java.util.Scanner;


public class LoadFactory implements Factory{

	public LoadFactory(){
		
	}
	
	public Operation create(Scanner scanner) throws FactoryException {

		if (!scanner.hasNext()) {
			throw new FactoryException();
		}
	
		String eof = scanner.next();
		String data="";
		
		while(scanner.hasNext()){
			String line = scanner.next();
			
			if(line.equals(eof)){
				break;
			}
			else{
				data += line;
				data+="\n";
			}
		}

		return new LoadOperation(data);
	}

}

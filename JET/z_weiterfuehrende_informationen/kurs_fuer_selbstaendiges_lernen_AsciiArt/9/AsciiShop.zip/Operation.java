
public interface Operation {
	
	public AsciiImage execute(AsciiImage img) throws OperationException;

}

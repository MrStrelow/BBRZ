
public class LoadOperation implements Operation{

	private String data;
	OperationException ope = new OperationException();
	
	public LoadOperation(String data){
		this.data = data;
	}
	
	public AsciiImage execute(AsciiImage image) throws OperationException {
		AsciiImage ret = new AsciiImage(image);		
		int i=0;
		
		while(!data.isEmpty()){
			String line=data.substring(0, data.indexOf('\n'));	
			
			if(ret.getColAnz(0)==line.length() && i < ret.getLineAnz()){
				if(lineIsInCharSet(line, image)){					
					ret.setLine(i, line.toCharArray());
					i++;
					data=data.substring(data.indexOf('\n')+1);				}
				else{
					throw ope;
				}
			}
			else{
				throw ope;
			}
		}
		
		if(i<ret.getLineAnz()){
			throw ope;
		}
		return ret;
	}
	
	private boolean lineIsInCharSet(String line, AsciiImage image){
		boolean ret=false;
		char[] cline = line.toCharArray();
		int cnt=0;
		
		for(int i=0; i<line.length(); i++){
			for(int j=0; j<image.getCharSet().length(); j++){
				if(cline[i]==image.getCharSet().toCharArray()[j]){
					cnt++;
				}
			}
		}
		
		if(cnt==line.length()){
			ret=true;
		}
		
		return ret;
	}

}

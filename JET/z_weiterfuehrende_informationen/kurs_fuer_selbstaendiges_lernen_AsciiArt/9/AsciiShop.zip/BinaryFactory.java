import java.util.Scanner;


public class BinaryFactory implements Factory{

	public BinaryFactory(){
		
	}
	
	public Operation create(Scanner scanner) throws FactoryException {
		if (!scanner.hasNext()) {
			throw new FactoryException();
		}
		
		String threshold = scanner.next();
		
		return new BinaryOperation(threshold.charAt(0));
	}

}

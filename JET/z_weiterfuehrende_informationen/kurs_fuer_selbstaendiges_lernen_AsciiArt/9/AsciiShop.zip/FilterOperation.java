import java.util.ArrayList;
import java.util.Collections;


public abstract class FilterOperation implements Operation{

	public FilterOperation(){
		
	}
	
	public AsciiImage execute(AsciiImage image) throws OperationException {
		int grow = 1;
		int area = 3;
		char[][] temp;
		AsciiImage ret = new AsciiImage(image);

		for(int i=0; i<ret.getLineAnz(); i++){
			for(int j=0; j<ret.getLine(i).length(); j++){
				temp = growImage(image, grow).getArea(new AsciiPoint(j+grow, i+grow), area).getImage();
				ret.setPixel(new AsciiPoint(j,i), filter(temp, ret.getCharSet()));
			}
		}
		
		return ret;
	}
	
	public abstract char filter(char[][] temp, String charSet);
	
	public AsciiImage growImage(AsciiImage image, int grow){
		AsciiImage ret = new AsciiImage(image.getColAnz(0)+2*grow, image.getLineAnz()+2*grow, image.getCharSet().toCharArray());
		
		for(int i=grow; i<=image.getLineAnz(); i++){
			for(int j=grow; j<=image.getLine(i-grow).length(); j++){
				ret.setPixel(j, i, image.getPixel(new AsciiPoint(j-grow, i-grow)));
			}
		}
		
		return ret;
	}
	
	public ArrayList<Character> sort(ArrayList<Character> list, String charSet){
		ArrayList<Character> ret = new ArrayList<Character>();
		ArrayList<Integer> number = new ArrayList<Integer>();
		
		for(Character c : list){
			for(int i=0; i<charSet.toCharArray().length; i++){
				if(c==charSet.toCharArray()[i]){
					number.add(i);
				}
			}
		}
		
		Collections.sort(number);
		
		for(Integer a : number){
			ret.add(charSet.toCharArray()[a]);
		}
		
		return ret;
	}
}

import java.util.HashMap;
import java.util.Scanner;


public class AsciiShop {

	public static void main(String[] args){
		
		Scanner sc = new Scanner(System.in);
		AsciiStack stack = new AsciiStack();
		AsciiImage image = null;
		HashMap<String, Factory> operations = new HashMap<String, Factory>();
		//ArrayList<Object> infoList = new ArrayList<Object>();
		
		boolean inputError = false;
		boolean unknownOperation = false;
		
		operations.put("binary", new BinaryFactory());
		operations.put("clear", new ClearFactory());
		operations.put("filter", new FilterFactory());
		operations.put("load", new LoadFactory());
		operations.put("replace", new ReplaceFactory());
		
		if(sc.next().equals("create")){

			if(sc.hasNextInt()){
				int xCreate=sc.nextInt();
				
				if(sc.hasNextInt()){
					int	yCreate=sc.nextInt();
					
					if(sc.hasNext()){
						String charset = sc.next();
						
						if(xCreate>0 && yCreate>0){
							image = new AsciiImage(xCreate, yCreate, charset.toCharArray());
						}else{
							inputError=true;
						}	
					}
				}
			}
			else{
				inputError=true;
			}
		}
		else{
			inputError=true;
		}
		
		while(!inputError && sc.hasNext()){
			String comline = sc.next();
			unknownOperation=false;
			
			if(comline.equals("undo")){				
				image = stack.pop();
			}	
			else if(comline.equals("print")){
				System.out.println(image.toString());
				//System.out.println(stack.size());
				//System.out.println(image.getColAnz(0) + " " + image.getLineAnz());
			}
			else if(operations.get(comline) != null){
				Factory fac = operations.get(comline);
				try {
					Operation op;
					op = fac.create(sc);
					try {
						stack.push(image);
						image = op.execute(image);
					} catch (OperationException e) {
						System.out.println(e.getMessage());
						System.exit(0);
					}
				} catch (FactoryException e) {
					System.out.println(e.getMessage());
					System.exit(0);
				}
			}
			else{
				unknownOperation=true;
				break;
			}
		}	
		
		if(inputError == true)				System.out.println("INPUT MISMATCH");
		if(unknownOperation == true)		System.out.println("UNKNOWN COMMAND");			
				
		sc.close();
	}	
}
/*
create 6 4 asdf
load t
ssssss
ffdsdf
ddfdfd
dddddd
t
filter median
*/
import java.util.Scanner;


public class FilterFactory implements Factory{

	public FilterFactory(){
		
	}
	
	public Operation create(Scanner scanner) throws FactoryException {
		String line = scanner.next();
		if(line.equals("median")){
			return new MedianOperation();
		}
		else if(line.equals("average")){
			return new AverageOperation();
		}
		else{
			throw new FactoryException();
		}
		
	}

}

import java.util.ArrayList;



public class AsciiImage {

	private int yImage;
	private int xImage;
	private char[][] image; 
	char clearChar='.';
	ArrayList<Character> uniqueCharList = new ArrayList<Character>();
	
	public AsciiImage(int x, int y){
		this.yImage = y;
		this.xImage = x;
		image=new char[y][x];
		clear();
	}
	
	public AsciiImage(AsciiImage img){
		this(img.xImage, img.yImage);
		
		for(int i = 0; i < img.image.length; i++){
			for(int j = 0; j < img.image[i].length; j++){
				this.image[i][j] = new Character(img.image[i][j]);
			}
		}	
	}
	
	//bestimmt den Schwerpunkt aller Pixel mit dem Zeichen c und gibt diesen als AsciiPoint zur�ck. Kommt das Zeichen nicht vor, so wird null zur�ckgegeben.	
	public AsciiPoint getCentroid(char c){
		AsciiPoint center;
		double x=0;
		double y=0;
		
		ArrayList<AsciiPoint> characterPoints = getPointList(c);
		
		if(characterPoints != null){
			for(AsciiPoint point : characterPoints){
				x+=point.getX();
				y+=point.getY();
			}
			
			x/=characterPoints.size();
			y/=characterPoints.size();
			center = new AsciiPoint((int)Math.round(x), (int)Math.round(y));
			
			return center;
		}
		else{
			return null;
		}
	}
	
	public ArrayList<AsciiPoint> getPointList(char c){
		ArrayList<AsciiPoint> characterPoints = new ArrayList<AsciiPoint>();
		int pointCnt=0;
		
		for(int i=0; i<image.length; i++){
			for(int j=0; j<image[i].length; j++){
				if(getPixel(j, i)==c){
					characterPoints.add(new AsciiPoint(j, i));
					pointCnt++;
				}
			}
		}
		if(pointCnt==0){
			return null;
		}
		else{
			return characterPoints;	
		}
	}
	
	public char[][] getImage(){
		return image;
	}
	
	public String toString(){
		String ret = "";
		
		for(char[] a : image){
			for(char b : a){
				ret+=b;
			}
			ret+="\n";
		}
		
		return ret;
	}
	
    /*public void addLine(String line){ //exception
		if(line.length() == xImage){
			image[yCount]=line.toCharArray();
			yCount++;
		}
	}*/
	
	public void growRegion(char c){	
		for(AsciiPoint point : getPointList(c)){		
				
			if(point.getX()+1 < image[0].length){
				if(getPixel(point.getX()+1, point.getY()) != c && getPixel(point.getX()+1, point.getY()) == clearChar){
					setPixel(point.getX()+1, point.getY(), c);
				}
			}
				
			if(point.getX()-1 >= 0){
				if(getPixel(point.getX()-1, point.getY()) != c && getPixel(point.getX()-1, point.getY()) == clearChar){
					setPixel(point.getX()-1, point.getY(), c);
				}	
			}
				
			if(point.getY()+1 < image.length){
				if(getPixel(point.getX(), point.getY()+1) != c && getPixel(point.getX(), point.getY()+1) == clearChar){
					setPixel(point.getX(), point.getY()+1, c);
				}
			}
				
			if(point.getY()-1 >= 0){
				if(getPixel(point.getX(), point.getY()-1) != c && getPixel(point.getX(), point.getY()-1) == clearChar){
					setPixel(point.getX(), point.getY()-1, c);
				}	
			}				
		}
	}
	
	public String getLine(int index){
		return new String(image[index]);	// basdfasfdas .toString oder so
	}
	
	public void setLine(int y, char[] newLine){
		if(y<yImage){
			image[y]=newLine;	
		}
		else{
			//System.out.println("nope");
		}
	}
	
	public int getLineAnz(){ // getWidth
		return image.length;
	}
	
	public void transpose(){
		char [][] tempImage = new char[xImage][yImage];
		
		for(int i=0; i<image.length; i++){
			for(int j=0; j<image[i].length; j++){
				tempImage[j][i] = image[i][j];		//setPixel verwenden
			}
		}
		
		image = tempImage;
		yImage=tempImage.length;
		xImage=tempImage[0].length;
	}
	
	public void fill(AsciiImage image, int x, int y, char c){ 
		
		char old = image.getPixel(x, y);
		String firstPart = image.getLine(y).substring(0, x);
		String lastPart = image.getLine(y).substring(x+1);
		image.setLine(y, (firstPart + c + lastPart).toCharArray());  
		
		if(x < image.getLine(y).length() - 1){
			if(image.getPixel(x + 1, y) == old){
				fill(image, x + 1, y, c); // rechts -> x++	
			}
		}			
		if(y < image.getLineAnz() - 1){
			if(image.getPixel(x, y + 1) == old){
				fill(image, x, y + 1 , c); // unten -> y++	
			}
		}			
		if(x > 0){
			if(image.getPixel(x - 1, y) == old){
				fill(image, x - 1, y, c); // links -> x--	
			}
		}			
		if(y > 0){
			if(image.getPixel(x, y - 1) == old){
				fill(image, x, y - 1, c); // oben -> y--	
			}
		}
	}
	
	public void flipVert(){ // rotiert an horizontaler achse
		AsciiImage swapImage = new AsciiImage(this.xImage, this.yImage);
		
		for(int i=image.length-1; i>0; i--){	
			swapImage.setLine(image.length-i-1, image[i]);
		}
		
		this.setImage(swapImage.getImage());
	}
	
	public void flipHor(){ // rotiert an vertikaler achse
		AsciiImage swapImage = new AsciiImage(this.xImage, this.yImage);
		
		for(int i=0; i<image.length; i++){
			char[] swap = new char[image[i].length];
			
			for(int j = image[i].length-1; j >= 0; j--){
				swap[image[i].length - 1 - j] = image[i][j];
			}
			
			swapImage.setLine(i, swap);
		}
		
		this.setImage(swapImage.getImage());
	}

	public int getColAnz(int index) { // getHight
		return xImage;
	}
	
	public int getUniqueCharsAnz(){
		ArrayList<Character> ucl = new ArrayList<Character>();
		
		for(char[] a : image){
			for(int i = 0; i < a.length; i++){
				if(!ucl.contains(a[i])){
					ucl.add(a[i]);
				}
			}
		}
		return ucl.size();
	}
	
	public void setImage(char[][] arg){
		image=arg;
	}

	public void drawLine(int x1, int y1, int x2, int y2, char c){
		double dy1 = y1;
		double dx1 = x1;
		double deltaX = x2-x1;
		double deltaY = y2-y1;
		double ratioY = Math.abs(deltaY / deltaX);
		double ratioX = Math.abs(deltaX / deltaY);
		
		if(x1>=0 && x2<xImage && y1>=0 && y2<yImage){
			if(Math.abs(deltaX) >= Math.abs(deltaY) && deltaX >= 0){ // es gibt 8 F�lle 
				
				for(; x1!=x2; x1++){
					setPixel(x1, (int) Math.round(dy1), c); // abfrage f�r sicherheit fehlt
					
					if(y1<y2)		dy1+=ratioY;
					else if(y2<y1)	dy1-=ratioY;		
				}	
				setPixel(x1, (int) Math.round(dy1), c);
			} 
			else if(Math.abs(deltaX) >= Math.abs(deltaY) && deltaX < 0){
				
				for(; x1!=x2; x1--){
					setPixel(x1, (int) Math.round(dy1), c); // abfrage f�r sicherheit fehlt
					
					if(y1<y2)		dy1+=ratioY;
					else if(y2<y1)	dy1-=ratioY;	
				}	
				setPixel(x1, (int) Math.round(dy1), c);
			}	
			else if(Math.abs(deltaY) >= Math.abs(deltaX) && deltaY >= 0){
				
				for(; y1!=y2; y1++){
					setPixel((int) Math.round(dx1), y1 , c); // abfrage f�r sicherheit fehlt
					
					if(x1<x2)		dx1+=ratioX;
					else if(x2<x1)	dx1-=ratioX;
				}	
				setPixel((int) Math.round(dx1), y1 , c);
			}	
			else if(Math.abs(deltaY) >= Math.abs(deltaX) && deltaY < 0){
				
				for(; y1!=y2; y1--){
					setPixel((int) Math.round(dx1), y1 , c); // abfrage f�r sicherheit fehlt
				
					if(x1<x2)		dx1+=ratioX;
					else if(x2<x1)	dx1-=ratioX;
				}	
				setPixel((int) Math.round(dx1), y1 , c);
			}	
		}
	}

	public void clear(){
		//char[][] clearImage = new char[yImage][xImage];
		
		/*for(char[] l : clearImage){		//seiteneffekte werden verwendet -> methoden getPixel/setPixel werden nicht verwendet
			for(int i=0; i<l.length; i++){
				l[i]='.';	
			}
		}*/
		
		/*besser*/
		for(int i=0; i<this.getImage().length; i++){
			for(int j=0; j<this.getLine(i).length(); j++){
				this.setPixel(j, i, clearChar);
			}
		}
		
		//image=clearImage; 
	}
	
	public char getPixel(int x, int y){
		return image[y][x];
	}
	
	//gibt, analog zur Methode public char getPixel(int x, int y), das Zeichen, an der durch p spezifizierten Stelle, zur�ck.
	public char getPixel(AsciiPoint point){
		return image[point.getY()][point.getX()];
	}

	public void setPixel(int x, int y, char c){
		image[y][x]=c;
	}
	
	public void setPixel(AsciiPoint point, char c){
		image[point.getY()][point.getX()]=c;
	}
	
	public void replace(char oldChar, char newChar){
		for(char[] line : image){
			for(int i=0; i<line.length; i++){
				if(line[i]==oldChar){
					line[i]=newChar;
				}
			}
		}
	}

}
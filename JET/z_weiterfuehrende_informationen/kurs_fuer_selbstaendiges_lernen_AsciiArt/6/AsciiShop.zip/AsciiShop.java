import java.util.Scanner;


public class AsciiShop {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		AsciiStack stack = new AsciiStack(3);
		AsciiImage image = null;
		//ArrayList<Object> infoList = new ArrayList<Object>();
		
		boolean inputError = false;
		boolean operationFailedError = false;
		boolean unknownOperation = false;
		
		if(sc.next().equals("create")){

			if(sc.hasNextInt()){
				int xCreate=sc.nextInt();
				if(sc.hasNextInt()){
					int	yCreate=sc.nextInt();
					
					if(xCreate>0 && yCreate>0){
						image = new AsciiImage(xCreate, yCreate);
						//stack.push(new AsciiImage(image));
					}else{
						inputError=true;
					}
				}
			}
			else{
				inputError=true;
			}
		}
		else{
			inputError=true;
		}
		
		while(!inputError && sc.hasNext()){
			String comline = sc.next();
			inputError=false;
			operationFailedError=false;
			unknownOperation=false;
			
			if(comline.equals("load")){
				String eof = sc.next();
				int i=0;
				while(sc.hasNext()){
					String line = sc.next();
					if(line.equals(eof)){
						if(i<image.getLineAnz()){
							inputError=true;
						}
						break;
					}
					else{
						if(image.getColAnz(0)==line.length() && i < image.getLineAnz()){
							image.setLine(i, line.toCharArray());
							i++;
						}else{
							inputError=true;
							break;
						}
					}
				}
				stack.push(new AsciiImage(image));
				
			}else if(comline.equals("line")){
				//if(sc.hasNextInt() && sc.hasNextInt() && sc.hasNextInt() && sc.hasNextInt()){ wenn ich line 0 0 4 4e eingebe ist die abfrae der 4 hasNextInt true. jedoch wird bei sc.hasNextInt die 4e eingelesen... warum?
					if(sc.hasNextInt()){
						int x1=sc.nextInt();
						
						if(sc.hasNextInt()){
							int y1=sc.nextInt();
							
							if(sc.hasNextInt()){
								int x2=sc.nextInt();
								
								if(sc.hasNextInt()){
									int y2=sc.nextInt();		
									char lineChar=sc.next().charAt(0);
									
									if(x1>=0 && x2<image.getColAnz(0) && y1>=0 && y2<image.getLineAnz()){
										image.drawLine(x1, y1, x2, y2, lineChar);
										stack.push(new AsciiImage(image));
										
									}else{
										inputError=true;
									}
								}
						}
					}
				} 
					
			}else if(comline.equals("clear")){
				image.clear();
				stack.push(new AsciiImage(image));
					
			}else if(comline.equals("replace")){
				char cOld = sc.next().charAt(0);
				char cNew = sc.next().charAt(0);
				
				image.replace(cOld, cNew);
				stack.push(new AsciiImage(image));
		
			}
			else if(comline.equals("fill")){
				
				if(sc.hasNextInt()){
					int xFill = sc.nextInt();
					 
					if(sc.hasNextInt()){
						int yFill = sc.nextInt();	
						char cFill = sc.next().charAt(0);
							
						if(image.getLineAnz() > yFill && yFill >= 0 && image.getColAnz(yFill) > xFill && xFill >= 0){
							image.fill(image, xFill, yFill, cFill);
							stack.push(new AsciiImage(image));
						}
						else{
							operationFailedError=true;
							break;
						}
					}
				}
				else{
					unknownOperation=true;
					break;
				}
			}
			else if(comline.equals("transpose")){
				image.transpose();
				stack.push(new AsciiImage(image));
			}
			else if(comline.equals("flip-y")){
				image.flipVert();
				stack.push(new AsciiImage(image));
			}
			else if(comline.equals("flip-x")){
				image.flipHor();
				stack.push(new AsciiImage(image));
			}
			else if(comline.equals("undo")){				
				if(stack.pop() != null){
					image = stack.peek();
					//infoList.add(image);
				}
			}
			else if(comline.equals("grow")){
				if(sc.hasNext()){
					char c=sc.next().charAt(0);
					image.growRegion(c);
					stack.push(new AsciiImage(image));
				}
			}
			else if(comline.equals("centroid")){
				if(sc.hasNext()){
					char c=sc.next().charAt(0);
					//infoList.add(image.getCentroid(c));	
					System.out.println(image.getCentroid(c) != null ? image.getCentroid(c) : "null");
				}
			}
			else if(comline.equals("print")){
				System.out.println(stack.peek().toString());
				//System.out.println(image.getColAnz(0) + " " + image.getLineAnz());
			}
			else{
				unknownOperation=true;
				break;
			}
		}	
		
		/*if(!infoList.isEmpty()){
			for(Object o : infoList){
				System.out.println(o);
			}
		}*/
		if(inputError == true)				System.out.println("INPUT MISMATCH");
		if(operationFailedError == true)	System.out.println("OPERATION FAILED");
		if(unknownOperation == true)		System.out.println("UNKNOWN COMMAND");			
				
		sc.close();
	}	
}
/*

*/
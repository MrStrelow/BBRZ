
public class AsciiStack {
	
	private AsciiImage[] stack;
	private int increment;
	
	//erzeugt einen Stack, der initial increment Elemente speichern kann. Sie d�rfen davon ausgehen, dass increment gr��er 0 ist. Das Parameter increment gibt auch an, um wieviel der Stack bei Bedarf vergr��ert bzw. verkleinert werden soll.
	public AsciiStack(int increment){
		stack = new AsciiImage[increment];
		this.increment = increment;
	}
	
	//gibt die Anzahl der Stack bereit stehenden Pl�tze zur�ck (sprich wie gro� das zu Grunde liegende Array ist). 
	//Aufgrund der Vorgehensweise bei Verg��erung und Verkleinerung, ist das Ergebnis dieser Methode immer ein Vielfaches von increment.
	public int capacity(){
		return stack.length;
	}
	
	//�berpr�ft, ob der Stack leer ist. In diesem Fall liefert die Methode true. Wenn mindestens ein Element am Stack liegt liefert die Methode false.
	public boolean empty(){
		return stack[0]==null;
	}
	
	//gibt das oberste Element am Stack zur�ck und entfernt dieses. Liegt kein Element am Stack, so soll null zur�ckgegeben werden. 
	//Sind nach dem Entfernen mehr als increment Pl�tze leer, so soll der Stack um increment verkleinert werden. 
	//Jedoch soll der Stack nie kleiner als increment sein, sprich wenn alle Elemente entfernt wurden, soll die Kapazit�t des Stacks gleich increment sein.
	public AsciiImage pop(){
		if(!empty()){
			AsciiImage retImage = stack[size()-1];
			stack[size()-1] = null;			
			
			System.out.println("STACK USAGE "+size()+"/"+capacity());
			
			if((capacity() - size()) >= increment){
				if(size() == 0){
					AsciiStack tempStack = new AsciiStack(increment);
					stack = tempStack.stack;
				}
				else{
					AsciiStack tempStack = new AsciiStack(capacity() - increment);
					
					for(int i=0; i<tempStack.stack.length; i++){
						tempStack.stack[i] = stack[i];
					}
					
					stack = tempStack.stack;	
				}
			}

			return retImage;
		}else{
			System.out.println("STACK EMPTY");
			return null;
		}
	}
	
	
	public AsciiImage peek(){ //gibt das oberste Element am Stack zur�ck ohne es zu entfernen. Liegt nichts am Stack, so soll null zur�ckgegeben werden.
		if(size()!=0){
			return new AsciiImage(stack[size()-1]);
		}else{
			return null;
		}
	}
	
	public void push(AsciiImage img){ //legt ein AsciiImage oben auf den Stack. Ist der Stack zu diesem Zeitpunkt voll, so soll der Stack um increment vergr��ert werden um so das Bild speichern zu k�nnen.
		if((size() - capacity()) < 0){
			stack[size()]=img;	
		}
		else{
			AsciiStack tempStack = new AsciiStack(capacity() + increment);
			
			for(int i=0; i<stack.length; i++){
				tempStack.stack[i] = stack[i];
			}
			
			stack = tempStack.stack;
			stack[size()]=img;
		}
	}
	
	public int size(){ //gibt die Anzahl der im Stack belegten Pl�tze zur�ck.
		int cnt=0;
		
		for(int i=0; i<stack.length; i++){
			if(stack[i]!=null){
				cnt++;
			}
		}
		return cnt;
	}
}

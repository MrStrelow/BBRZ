import java.util.Scanner;


public class AsciiShop {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		AsciiImage image = null;
		
		boolean inputError = false;
		boolean operationFailedError = false;
		boolean unknownOperation = false;
		
		if(sc.next().equals("create")){

			if(sc.hasNextInt()){
				int xCreate=sc.nextInt();
				if(sc.hasNextInt()){
					int	yCreate=sc.nextInt();
					
					if(xCreate>0 && yCreate>0){
						image = new AsciiImage(xCreate, yCreate);
					}else{
						inputError=true;
					}
				}
			}
			else{
				inputError=true;
			}
		}
		else{
			inputError=true;
		}
		
		while(!inputError && sc.hasNext()){
			String comline = sc.next(); 
			inputError=false;
			operationFailedError=false;
			unknownOperation=false;
			
			if(comline.equals("load")){
				String eof = sc.next();
				int i=0;
				while(sc.hasNext()){
					String line = sc.next();
					if(line.equals(eof)){
						if(i<image.getLineAnz()){
							inputError=true;
						}
						break;
					}
					else{
						if(image.getColAnz(0)==line.length() && i < image.getLineAnz()){
							image.setLine(i, line.toCharArray());
							i++;
						}else{
							inputError=true;
							break;
						}
					}
				}
				
			}else if(comline.equals("line")){
				//if(sc.hasNextInt() && sc.hasNextInt() && sc.hasNextInt() && sc.hasNextInt()){ wenn ich line 0 0 4 4e eingebe ist die abfrae der 4 hasNextInt true. jedoch wird bei sc.hasNextInt die 4e eingelesen... warum?
					if(sc.hasNextInt()){
						int x1=sc.nextInt();
						
						if(sc.hasNextInt()){
							int y1=sc.nextInt();
							
							if(sc.hasNextInt()){
								int x2=sc.nextInt();
								
								if(sc.hasNextInt()){
									int y2=sc.nextInt();		
									char lineChar=new Character(sc.next().charAt(0));
									
									image.drawLine(x1, y1, x2, y2, lineChar);
								}
						}
					}
				} 
					
			}else if(comline.equals("clear")){
				image.clear();
					
			}else if(comline.equals("replace")){
				char cOld = new Character(sc.next().charAt(0));
				char cNew = new Character(sc.next().charAt(0));
				
				image.replace(cOld, cNew);
		
			}
			else if(comline.equals("fill")){
				
				if(sc.hasNextInt()){
					int xFill = sc.nextInt();
					 
					if(sc.hasNextInt()){
						int yFill = sc.nextInt();	
						char cFill = new Character(sc.next().charAt(0));
							
						if(image.getLineAnz() > yFill && yFill >= 0 && image.getColAnz(yFill) > xFill && xFill >= 0){
							image.fill(image, xFill, yFill, cFill);
						}
						else{
							operationFailedError=true;
							break;
						}
					}
				}
				else{
					unknownOperation=true;
					break;
				}
			}
			else if(comline.equals("transpose")){
				image.transpose();
			}
			else if(comline.equals("flip-y")){
				image.flipVert();
			}
			else if(comline.equals("flip-x")){
				image.flipHor();
			}
			else if(comline.equals("print")){
				System.out.println(image.toString());
				//System.out.println(image.getColAnz(0) + " " + image.getLineAnz());
			}
			else{
				unknownOperation=true;
				break;
			}
		}	
		
		if(inputError == true)				System.out.println("INPUT MISMATCH");
		if(operationFailedError == true)	System.out.println("OPERATION FAILED");
		if(unknownOperation == true)		System.out.println("UNKNOWN COMMAND");			
				
		sc.close();
	}	
}
/*

*/
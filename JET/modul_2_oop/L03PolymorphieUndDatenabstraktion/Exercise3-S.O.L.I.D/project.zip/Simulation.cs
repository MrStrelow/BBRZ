﻿using System.Text;

namespace Hamster;

public class Simulation
{
    static void Main(string[] args)
    {
        // User Intput:
        Console.OutputEncoding = Encoding.UTF8;

        string promotForUser = "How large should the plane be?: ";
        Console.Write(promotForUser);

        int sizeOfPlane;

        while (!int.TryParse(Console.ReadLine(), out sizeOfPlane))
        {
            Console.Clear();

            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Input is not an integer number. Please try again.");
            Console.ResetColor();

            Console.Write(promotForUser);
        }

        Console.Clear();
        Console.CursorVisible = false;

        // Start der Simulation:
        Plane plane = new Plane(sizeOfPlane); // TODO factory method.
        IRenderer renderer = new ConsoleRenderer(plane) { TimeToSleepMs = 500 }; // TODO factory method.
        //IRenderer renderer = new HtmlRenderer(plane) { TimeToSleepMs = 500 }; // TODO factory method.
        plane.Renderer = renderer; // TODO factory method.

        while (true)
        {
            // Logik Methoden
            // simulate hamster
            plane.SimulateHamster();

            //// simulate Seedlinglings
            plane.SimulateSeedling();

            // Darstellungs Methoden
            //// Darstellung anzeigen
            renderer.Render();
        }

    }
}
import java.util.Scanner;


public class AsciiShop {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		boolean start = true;
		AsciiImage image = null;
		boolean read = true;
		boolean output = true;
		int readLine = 0;
		int x;
		int y;
		char c;
		
		if(sc.next().equals("read")){
			
			if(sc.hasNextInt()) readLine = sc.nextInt();				
			
			for(int i = 0; i < readLine; i++){
				
				String line=sc.next();
					
				if(start){ 		// abfrage ob die referenzzeile zu setzen ist 
					start=false;
					image = new AsciiImage(line.length(), readLine);
				}
				else if(line.length() != image.getColAnz(0)){ // wird ersetzt durch try catch 
					read = false;
					output = false;
					System.out.println("INPUT MISMATCH");										
					break;										//fehler liegt vor -> verlasse schleife sofort
				}				
				
				image.addLine(line);	
			}
			
			while(read && sc.hasNext()){	// read um zu vermeiden dass inputmissmatch 2 mal ausgegeben wird wenn 27 zeilen eingelesen werden sollten aber nur 5 eingegeben wurden
				String next = sc.next();
				output = false;				// um ausgabe zu vermeiden wenn einmal ein richtiger befehl eingegeben wurde jedoch der n�chste falsch ist
					
				if(next.equals("fill")){
					if(sc.hasNextInt()){	// um  fehler  abzufangen -> fill e 2 #
						x = sc.nextInt();
						
						if(sc.hasNextInt()){	// um folgefehler abzufangen -> fill 1 e #
							y = sc.nextInt();	
							c = sc.next().toCharArray()[0];		// ben�tigt keine �berpr�fung -> fill 1 0 asdfasdfasdf -> es wird 'a' als char genommen
						}
						else{
							System.out.println("INPUT MISMATCH");
							break;
						}
					}
					else{
						System.out.println("INPUT MISMATCH");
						break;
					}
					
					if(image.getLineAnz() > y && y >= 0 && image.getColAnz(y) > x && x >= 0){
						image.fill(image, x, y, c);
					}
					else{
						System.out.println("OPERATION FAILED");
						break;
					}	
				}
				else if(next.equals("flip-v")){
					image.flipVert();
				}
				else if(next.equals("flip-x")){
					image.flipHor();
				}
				else if(next.equals("transpose")){
					image.transpose();
				}
				else if(next.equals("uniqueChars")){
					System.out.println(image.getUniqueCharsAnz());
				}
				else{
					System.out.println("INPUT MISMATCH");
					break;
				}
				
				output = true;	 // wird auf true gesetz -> wenn das programm hier ist muss die eingabe ture sein
			}
		}
		else{
			System.out.println("INPUT MISMATCH");
		}
				
		if(output){
			System.out.println(image.toString());
			System.out.println(image.getLine(0).length() + " " + image.getLineAnz());	
		}
		
		sc.close();
	}	
}

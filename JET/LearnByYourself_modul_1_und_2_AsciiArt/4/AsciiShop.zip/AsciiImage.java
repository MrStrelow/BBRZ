import java.util.ArrayList;



public class AsciiImage {

	int yImage;
	int xImage;
	ArrayList<String> image = new ArrayList<String>();
	ArrayList<Character> uniqueCharList = new ArrayList<Character>();
	
	public AsciiImage(int x, int y){
		this.yImage = y;
		this.xImage = x;
	}
	
	public ArrayList<String> getImage(){
		return image;
	}
	
	public String toString(){
		String ret = "";
		for(String s : image){
			ret+=s;
			ret+="\n";
		}
		return ret;
	}
	
	public void addLine(String line){
		if(line.length() == xImage){
			image.add(line);
		}
	}
	
	public String getLine(int index){
		return image.get(index);	
	}
	
	public void setLine(int y, String newLine){
		image.set(y, newLine);
	}
	
	public int getLineAnz(){ // getWidth
		return image.size();
	}
	
	public void transpose(){
		AsciiImage swapImage = new AsciiImage(this.yImage, this.xImage);
		
		char [][] tempImage = new char[this.xImage][this.yImage];
		
		for(int i=0; i<tempImage.length; i++){
			for(int j=0; j<tempImage[i].length; j++){
				tempImage[i][j]=image.get(j).charAt(i);	
			}
		}
		
		for(int i=0; i<tempImage.length; i++){
			swapImage.addLine(String.valueOf(tempImage[i]));
		}
		
		image=swapImage.image;
		yImage=swapImage.yImage;
		xImage=swapImage.xImage;
	}
	
	public void fill(AsciiImage image, int x, int y, char c){ 
		
		char old = image.getLine(y).charAt(x);
		String firstPart = image.getLine(y).substring(0, x);
		String lastPart = image.getLine(y).substring(x+1);
		image.setLine(y, firstPart + c + lastPart);  
		
		if(x < image.getLine(y).length() - 1){
			if(image.getLine(y).charAt(x + 1) == old){
				fill(image, x + 1, y, c); // rechts -> x++	
			}
		}			
		if(y < image.getLineAnz() - 1){
			if(image.getLine(y + 1).charAt(x) == old){
				fill(image, x, y + 1 , c); // unten -> y++	
			}
		}			
		if(x > 0){
			if(image.getLine(y).charAt(x - 1) == old){
				fill(image, x - 1, y, c); // links -> x--	
			}
		}			
		if(y > 0){
			if(image.getLine(y - 1).charAt(x) == old){
				fill(image, x, y - 1, c); // oben -> y--	
			}
		}
	}
	
	public void flipVert(){ // rotiert an horizontaler achse
		AsciiImage swapImage = new AsciiImage(this.xImage, this.xImage);
		
		for(int i=image.size(); i>0; i--){
			swapImage.addLine(image.get(i-1));
			
		}
		
		image = swapImage.image;
	}
	
	public void flipHor(){ // rotiert an vertikaler achse
		AsciiImage swapImage = new AsciiImage(this.xImage, this.yImage);
		
		for(String a : image){
			char[] swap = new char[a.length()];
			
			for(int i = a.length(); i > 0; i--){
				swap[a.length() - i] = a.charAt(i-1);
			}
			
			swapImage.addLine(String.valueOf(swap));
		}
		
		image = swapImage.image;
	}

	public int getColAnz(int index) { // getHight
		return xImage;
	}
	
	public int getUniqueCharsAnz(){
		ArrayList<Character> ucl = new ArrayList<Character>();
		
		for(String a : image){
			for(int i = 0; i < a.length(); i++){
				if(!ucl.contains(a.charAt(i))){
					ucl.add(a.charAt(i));
				}
			}
		}
		return ucl.size();
	}
}
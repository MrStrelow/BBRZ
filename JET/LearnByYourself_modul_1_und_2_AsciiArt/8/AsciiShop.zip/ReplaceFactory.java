import java.util.Scanner;


public class ReplaceFactory implements Factory{

	public ReplaceFactory(){
		
	}
	
	public Operation create(Scanner scanner) throws FactoryException {
		char[] params = new char[2];

		for (int i = 0; i < params.length; i++) {
			if (!scanner.hasNext()) {
				throw new FactoryException();
			}
			String s = scanner.next();
			if (s.length() > 1) {
				throw new FactoryException();
			}
			params[i] = s.charAt(0);
		}

		return new ReplaceOperation(params[0], params[1]);
	}

}

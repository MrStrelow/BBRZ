import java.util.Scanner;


public class FilterFactory implements Factory{

	public FilterFactory(){
		
	}
	
	public Operation create(Scanner scanner) throws FactoryException {
		if(!scanner.next().equals("median") || !scanner.hasNext()){
			throw new FactoryException();
		}
		return new MedianOperation();
	}

}

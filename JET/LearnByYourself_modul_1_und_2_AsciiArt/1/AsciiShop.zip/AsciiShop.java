import java.util.Scanner;

public class AsciiShop {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int refLength = 0;	// anzahl der char der eingegebenen zeile
		int lineQuant = 0;	// zum z�hlen der anzahl der eingegebenen zeilen
		boolean fail=false; // f�r unterscheidung der ausgabe n�tig
		
		while(sc.hasNextLine()){ 		// abfrage der n�chsten zeile -> gibt wert true zur�ck wenn eingabe erfolgt
			lineQuant++;				// zeile gefunden -> erh�hung des zeilenz�hlers
			if(refLength == 0){ 		// abfrage ob die referenzzeile zu setzen ist 
				refLength = sc.nextLine().length();	// setzen der referenzzeile -> erste eingabe
			}
			else if(sc.nextLine().length() != refLength){ 	// wenn referenz besteht, l�nge der aktuellen zeile mit ref.-l�nge vgl.
				System.out.println("INPUT MISMATCH");		
				fail=true;									
				break;										//fehler liegt vor -> verlasse schleife sofort
			}
		}
		
		if(!fail){ 	// wenn die bedingung !fail zutrifft liegt eine richtige eingabe vor.
			System.out.println(refLength+" "+lineQuant);
		}
		
		sc.close(); // stream schlie�en 
	}

}

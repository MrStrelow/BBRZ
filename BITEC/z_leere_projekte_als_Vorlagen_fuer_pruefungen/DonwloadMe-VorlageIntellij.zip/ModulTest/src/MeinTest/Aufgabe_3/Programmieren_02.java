package MeinTest.Aufgabe_3;

public class Programmieren_02 {
    public static void main(String[] args) {
        System.out.println("hello, me work.");
    }
}